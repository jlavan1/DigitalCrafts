function myRecipe(){
	console.log("""In a medium, heavy-bottomed saucepan, combine the tomatoes (with their juices), halved onion, garlic cloves, olive oil, oregano and red pepper flakes. Bring the sauce to a simmer over medium-high heat, then lower the heat to keep the sauce at a slow, steady simmer for about 45 minutes, or until droplets of oil float free of the tomatoes. Stir occasionally, and use a sturdy wooden spoon to crush the tomatoes against the side of the pot after about 15 minutes has passed.Remove the pot from the heat and discard the onion. Smash the garlic cloves against the side of the pot with a fork, then stir the smashed garlic into the sauce. Do the same with any tiny onion pieces you might find. Use the wooden spoon to crush the tomatoes to your liking (you can blend this sauce smooth with an immersion blender or stand blender, if desired. Add salt, to taste (the tomatoes are already pretty salty, so you might just need a pinch. Serve warm. This sauce keeps well, covered and refrigerated, for up to 4 days. Freeze it for up to 6 months""");
}


myRecipe();
