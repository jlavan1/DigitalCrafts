let myArray = ["Joe", "Jamail", "Tee", "Keyna"]

const newArray = myArray.filter( (longerthan3, index) => longerthan3.length > 3);

console.log(newArray);