const Multiply = () =>{
    num1 = document.getElementById("Fnumber").value;
    num2 = document.getElementById("Snumber").value;
    document.getElementById("Result").innerHTML = num1 * num2;

    
}

const Divide = () =>{
    num1 = document.getElementById("Fnumber").value;
    num2 = document.getElementById("Snumber").value;

    docuument.getElementById("Result").innerHTML = num1 / num2;
}