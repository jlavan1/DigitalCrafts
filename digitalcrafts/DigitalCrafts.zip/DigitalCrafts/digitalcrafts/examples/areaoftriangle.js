const areaOfTriangle = (x, y) =>{
    let base = x
    let height = y

    console.log(((x * y) * .5))
}

areaOfTriangle(5,6);